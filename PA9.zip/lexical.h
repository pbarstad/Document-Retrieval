//Paul Barstad
//CS253 PA4
//10-8-17

#ifndef LEXICAL_H_INCLUDED
#define LEXICAL_H_INCLUDED

#include <string>
using namespace std;

class Lexical {
public:
//isVowel
	bool isVowel(string s, int location);

//isDouble
	bool isDouble(string s);

//isLIending
	bool isLIending(string s);	
	
//Region1
	string Region1(string s);

//Region2
	string Region2(string s);

//preceder
	string preceder(string s);

//isShortSyllable
	bool isShortSyllable(string s);

//isWordShort
	bool isWordShort(string s);

//replace suffix method
	

};
#endif
