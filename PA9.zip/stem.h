//Paul Barstad
//CS253 PA4
//10-8-17

#ifndef STEM_H_INCLUDED
#define STEM_H_INCLUDED

#include <string>
using namespace std;

class Stem {
public:

//STEP 1
	string step1(string s);
	//if string starts with an apostrophe... remove it
	
	//if suffix is 's' remove it

	//if suffix is 's remove it

	//if suffix is ' remove it

//STEP 2
	string step2(string s);
	//if suffix sses replace with ss

	//if suffix is ied or ies
		//if preceder is more than one letter replace with i

		//else replace with ie

	//if suffix is us replace with us (do nothing)

	//if suffix is ss replace with ss (do nothing)

	//if suffix is s and preceding word part contains a vowel 
	//not immediately before the s, remove the s

//STEP 3
	string step3(string s);
	//if suffix is eed or eedly and suffix occurs in region1 replace with ee

	//if suffix is... ed, edly, ing, ingly.. and the preceder contains a vowel
		//if preceder ends in at, bl, or iz... add an e

		//else if preceder ends in a double, remove the last letter
		
		//else if the preceder is short, add an e
		
		//else remove suffix

//STEP 4
	string step4(string s);
	//if suffix is y and follows a non-vowel that is not the first letter
	//of the preceder, replace the y with an i

//STEP 5
	string step5(string s);
	//if suffix is tional replace with tion

	//if suffix is enci replace with ence

	//if suffix is anci replace with ance

	//if suffix is abli replace with able

	//if suffix is entli replace with ent
	
	//if suffix is izer or ization replace with ize

	//if suffix is ational, ation, or ator replace with ate

	//if suffix is alism, aliti, or alli replace with al

	//if suffix is fulness replace with ful

	//if suffix is ousli or ousness replace with ous

	//if suffix is iveness or iviti replace with ive

	//if suffix is biliti or bli replace with ble

	//if suffix is ogi and suffix is preceded by l replace with og

	//if suffix is fulli replace with ful

	//if suffix is lessli replace with less

	//if suffix is li and preceder ends in valid li ending remove the li

//STEP 6
	string step6(string s);
	//if suffix is in Region1
		//if suffix is tional replace with tion
		
		//if suffix is ational replace with ate

		//if suffix is alize replace with al

		//if suffix is icate, iciti, or ical replace with ic

		//if suffix is ful or ness remove it

	//if suffix is ative and is in region2 remove it

//STEP 7
	string step7(string s);
	//if suffix is in region2
		//suffix is ... al, ance, ence, er, ic, able, ible, ant, ement, 
		//ment, ent, ism, ate, iti, ous, ive, or ize remove it
	
		//if suffix is ion, and the preceder ends with an s or t
		// remove it

//STEP 8
	string step8(string s);
	//if suffix is e
		//suffix appears in region2 or 
		//(region1 and preceder does not end in short syllable) 
			//remove the e

	//if suffix is l
		//suffix appears in region2 and preceder ends in l (word ends in ll)
			//remove one l

};

#endif
