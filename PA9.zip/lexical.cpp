//Paul Barstad
//CS253 PA4
//10-8-17

#include "lexical.h"
#include <string>
#include <iostream>
using namespace std;

//isVowel
	bool Lexical::isVowel(string s, int location) {
		char c = s.at(location);
		if(c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u')
			return true;
		if(c == 'y') {
			//does not follow another vowel and is not first letter in word... return true
			if(location != 0 && (isVowel(s, location-1) == false)) 
				return true;
		}
		return false;
	}

//isDouble
	bool Lexical::isDouble(string s) {
		//get substring
		if(s == "bb" || s == "dd" || s == "ff" || s == "gg" || s == "mm" || s == "nn" || s == "pp" || s == "rr" || s == "tt" ) {
			return true;
		}   
		return false;
	}

//isLIending
	bool Lexical::isLIending(string s) {
		string test = "";
		//check character before li s.substr(s.length()-3,1)
		if(s.length() > 2)	
			test = s.substr(s.length()-3, 1);
		if(test == "c" || test == "d" || test == "e" || test == "g" || test == "h" || test == "k" || test == "m" || test == "n" || test == "r" || test == "t") {
			return true;
		}
		return false;
	}
	
//Region1
	string Lexical::Region1(string s) {
		string str = "";
		//the substring after the first consonant that follows a vowel
		unsigned int i = 0;
		if(s.length() == 0) return "";
		while(isVowel(s, i) == false && i < s.length()-1) {
			i++;
		} //found first vowel
		while(isVowel(s, i) == true && i < s.length()-1) {
			i++;
		} //found next consonant
		//i++; //to get past the consonant found
		if(i < s.length())
			str = s.substr(i, s.length()-i); //if region1 is empty this will return "" an empty string
		return str;
	}

//Region2
	string Lexical::Region2(string s) {
		//if time try to code the correct y isVowel... from word not region1(word)
		//ABYSMAL
		string r1 = Region1(s);
		//cout << "r1 : " << r1 << endl;
		string str = Region1(r1);
		return str;
	}

//preceder
	string Lexical::preceder(string s) {
		unsigned int i = 0;
		while(isVowel(s, i) == false && i < s.length()-1) {
			i++;
		} //found first vowel
		while(isVowel(s, i) == true && i < s.length()-1) {
			i++;
		} //found next consonant
		string str = s.substr(0, i);
		return str;
	}

//isShortSyllable
	bool Lexical::isShortSyllable(string s) {
		if(s.length() == 2) {
			if(isVowel(s, 0) == true && isVowel(s, 1) == false) 
				return true;
		}
		if(s.length() > 2) {
			if(isVowel(s, s.length()-1) == false 
			&& isVowel(s, s.length()-2) == true
			&& isVowel(s, s.length()-3) == false)
				if(s.at(s.length()-1) != 'w' && s.at(s.length()-1) != 'x' && s.at(s.length()-1) != 'y')
					return true;
		}
		return false;
	}

//isWordShort
	bool Lexical::isWordShort(string s) {
		if(isShortSyllable(s) == true && Region1(s) == "")
			return true;
		return false;
	}

//replace suffix method









	
