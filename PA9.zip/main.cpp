//Paul Barstad
//CS253 PA4
//10-9-17

//need to get counts for every input file...
//which means two vectors created for every input file
//with the counts I need to create a new vector with TFDIF values for each file?
//then compare the two TFDIF values somehow and print?

#include <lexical.h>
#include <stem.h>
#include <doc.h>
#include<stdio.h>
#include<ctype.h>
#include<iostream>
#include<fstream>
#include<map>
#include<algorithm>
using namespace std;

int main(int argc, char *argv[]) {

	if(argc != 5) { //two files... two numbers for range
		cerr << "Wrong number of files" << endl;
		return -1;
	}
	if(argv[3] > argv[4]) {
		cerr << "invalid reading range" << endl;
		return -1;
	}
	double rangeLow = atof(argv[3]);
	double rangeHigh = atof(argv[4]);
	//read in exceptions file 
	//FLIP THE INPUT FILE NUMERS... THE FIRST FILE SHOULD BE EXCEPTIONS...
	
	string s;
	vector<string> fileNames;
	ifstream inFile;
	inFile.open(argv[2]);
	if(!inFile) { cerr << "cannot read the second file of files " << argv[2] << endl; return -1;}
	//int a = 0;
	while(inFile) {
		inFile >> s;
		if(s == "") break;
		//cout << s << endl;
		fileNames.push_back(s);
		s = "";
	}
	inFile.close();
  
  string next;
  string firstWord;
  string secondWord;
  vector<string> noStems;
  vector<string> exceptions;
  ifstream propFile;
  propFile.open(fileNames.at(0));
  if(!propFile) { cerr << "cannot read exceptions file " << fileNames.at(0) << endl; return -1; }
  while(!propFile.eof()) {
		getline(propFile, next); 
		unsigned int space = 0;
    for(unsigned int i = 0; i < next.length(); i++) {
    	//cout << "here with length " << next.length();
    	if(next.at(i) == ' ' && space == 0) { space = i; }

    	//what if is tab and space ?...
    	if(next.at(i) == ' ' && space != i && i != next.length()-1) { cerr << "more than two words on line in exception file" << endl; return -1; }//more than two words found...
    	if(i == next.length()-1 && space == 0) { cerr << "found no space on line in exception file" << endl; return -1; }//found no space therefore invalid exception file
    }
    if(next.length() != 0) {
    	firstWord = next.substr(0, space);
    	secondWord = next.substr(space+1, next.length()-space);
    }
    noStems.push_back(firstWord);
		exceptions.push_back(secondWord);
		firstWord = "";
		secondWord = "";        
  }
  propFile.close();
  
  vector<vector<string>> words;
  vector<string> wordsi;
  //ifstream inFile;
  inFile.open(argv[1]); //get the background document out front
  string z;
  while(inFile) {
  	inFile >> z;
  	if(z == "") break;
  	wordsi.push_back(z);
  	z = "";
  }
  inFile.close();
  if(wordsi.size() == 0) {
	cerr << "Empty input file x" << endl;
	return -1;
  }

  words.push_back(wordsi); //should have reference file?
  //cout << wordsi.size() << endl;
  for(unsigned int q = 1; q < fileNames.size(); q++) {
  	wordsi.clear();
    //cout << wordsi.size() << endl;
  	ifstream inFile;
		inFile.open(fileNames.at(q));
		string s;
		while(inFile) {
			inFile >> s;
			if(s == "") break;
			//cout << s << endl;
			wordsi.push_back(s);
			s = "";
		}
		//cout << "LL " << wordsi.at(0) << endl;
		//cout << "here1" << endl;
		inFile.close();
		if(wordsi.size() == 0) {
			cerr << "Empty input file " << fileNames.at(q) << endl;
			return -1;
		}
		//cout << "pushing" << endl;
		words.push_back(wordsi);	
  }
	//here and should have all files read in now check reading level of each document
		//cout << "down here" << endl;
	//cout << words.size() << endl;
	vector<vector<string>> punctuated;
	for(unsigned int x = 0; x < words.size(); x++) {
    //cout << words.at(x).size() << endl;
    //if(x == 0)
        punctuated.push_back(newPunc(words.at(x)));
	}
	//for(auto i : punctuated) { cout << "Punctuated " << i.size() << endl; }
	//cout << endl;
	//punctuated = newPunc(words);
	
	//cout << punctuated.size() << endl;
	//check the capitals 
	/* for(unsigned int x = 0; x < punctuated.size(); x++) {
	//vector<string> v = punctuated.at(x);
	
	for(unsigned int i = 0; i < punctuated.at(x).size(); i++) {
		bool sentence = false;
		if(isupper(punctuated.at(x).at(i).at(0)) && i == 0) { //first word in file ambiguous
			punctuated.at(x).at(i) = "+" + punctuated.at(x).at(i);
		}
		if(punctuated.at(x).at(i).length() > 0)
			if(isupper(punctuated.at(x).at(i).at(0))) { //if upper comes first elsewhere
				if(punctuated.at(x).at(i-1).length() > 0) {
					for(unsigned int b = 0; b < punctuated.at(x).at(i-1).length(); b++) { //through each character
						char current = punctuated.at(x).at(i-1).at(b);
						if(current == '.' || current == '!' || current == '?') 
							sentence = true;
					}
					if(sentence) {
						//cout << " + " << endl;
						punctuated.at(x).at(i) = "+" + punctuated.at(x).at(i);
					}
				}
				//cout << v.at(i) << endl;
			}
	}
	} */
	//sort(punctuated.begin(), punctuated.end());
	map<string, int> counts;
	vector<map<string, int>> readingLevelCounts;
  
	// CALCULATE READING LEVLS HERE BEFORE STEMMING
	for(unsigned int c = 0; c < punctuated.size(); c++) { //each document but skip the reference file
    //cout << fileNames.at(c) << endl;
    //cout << punctuated.at(c).size() << endl;
		for(unsigned int d = 0; d < punctuated.at(c).size(); d++) { //each word
			//change code from PA7 to accomodate multiple files, then store reading levels in vector of doubles
			if(d == 0) { //if no output
				//newvec.push_back(words.at(i)); //add new word
				//counts.push_back(1); //make count 1
				counts.insert(pair<string,int>(punctuated.at(c).at(d),1));
			}
			else if(counts.count(punctuated.at(c).at(d)) > 0) {
				counts[punctuated.at(c).at(d)]++;
				//counts.at(counts.size()-1)++; 
				//if word already added increment count
			}
			else {
				//newvec.push_back(words.at(i)); //otherwise add new word
				//counts.push_back(1); //make count one
				counts.insert(pair<string,int>(punctuated.at(c).at(d),1));
			}
			//if(c == 1)
        //cout << punctuated.at(c).at(d) << " " << counts[punctuated.at(c).at(d)] << endl;
		}
		readingLevelCounts.push_back(counts);
    //cout << endl;
	}
	
map<string, double> readingLevels;
//int N = fileNames.size();
//cout << "HERE" << endl;
	
for(unsigned int z = 1; z < readingLevelCounts.size(); z++) { //each document but skip exceptions
	//cout << "calculating reading level" << endl;
	int numWords = 0;
	int numLetters = 0;
	int numSentences = 0;
	for (map<string,int>::iterator it=readingLevelCounts.at(z).begin(); it!=readingLevelCounts.at(z).end(); ++it) { //through all words
		string temp = it->first;
		//if(newvec.at(a).at(0) == '.' ) cout << "found . at beginnning " << newvec.at(a) << endl;
		bool allPunct = true;
		bool sentence = false;
		//cout << newvec.at(a) << " " << counts.at(a) << endl;
		for(unsigned int b = 0; b < temp.length(); b++) { //through each character
			//cout << "ispunct " << ispunct(newvec.at(a).at(b)) << endl;
			char current = temp.at(b);
			if(current == '.' || current == '!' || current == '?') 
				sentence = true;
			if(!ispunct(temp.at(b))) {
				//cout << "notpunct " << newvec.at(a).at(b) << endl;
				allPunct = false;
			}
		}
		if(allPunct == true) {
			//punctuation++;
			//see if valid sentence punctuation ? ! .
			if(sentence) {
				//cout << newvec.at(a) << endl;
				numSentences += it->second;//counts.at(a);
			}
				//if yes increment numSentences
		}
		if(allPunct == false) {
			//cout << "not punctuation" << endl;
			//cout << newvec.at(a) << endl;
			//validWords.push_back(newvec.at(a));
			numWords += it->second;//counts.at(a);
			numLetters += (it->first.length() * it->second);
		}
		
	}
	if(numLetters == 0) {
		cerr << "NO LETTERS" << endl;
		return -1;
	}
	double val = (5.88 * numLetters/numWords) - (29.6 * numSentences/numWords) - 15.8;
	//cout << "gonna insert" << endl;
	if(z == 0) { 
		//don't want to insert the background file reading level
	}
	//else {
		readingLevels.insert(pair<string, double>(fileNames.at(z), val));
		/* cout << fileNames.at(z) << " " << val << endl;
		cout << "word count: " << numWords << endl;
		cout << "character count: " << numLetters << endl;
		cout << "sentence count: " << numSentences << endl;
		cout << endl; */
	//}
	//cout << "inserted" << endl;
	//numWords = 0; numLetters = 0; numSentences = 0;
}
	//cout << readingLevels.size() << endl;
	//bool valid = false;
	/*int random = -1;
	//bool first = true;
	for(map<string,double>::iterator it=readingLevels.begin(); it!=readingLevels.end(); ++it) {
		//cout << "here" << endl;
		//if(first) { ++it; first = false; }
		random++;
		if(it->second >= rangeLow && it->second <= rangeHigh) {
			//valid = true;
			//cout << it->first << " is in valid range" << endl;
			//ADD PUNCTUATED.at(whatever) to a new vector???
		} 
		else {
			//cout << it->first << " not in range" << endl;
			//punctuated.erase(punctuated.begin()+random);
			//NEED TO CHANGE PUNCTUATED VECTOR TO NOT HAVE THE BAD ONES
		}
	}
	if(punctuated.size() == 1) {
		cerr << "no valid reading levels!" << endl;
		return -1;
	} */
	//cout << readingLevels.size();
	//cout << "I AM HERE" << endl;
	/* for(map<string,double>::iterator it=readingLevels.begin(); it!=readingLevels.end(); ++it) {
		//cout << "HERE" << endl;
		//cout << it->first << " " << it->second << endl;
		if(it->second >= rangeLow && it->second <= rangeHigh) {
		
		}
	} */
	//cout << punctuated.size() << endl;
	
	//loop through vector of reading levels, if it contains valid ones, do TFIDF on those files!
	//error if valid reading level is not found
	
		//ambiguous capitals have a + now
	//cout << "HERE" << endl;
	Stem st;
	vector<vector<string>> ender;
	
	//cout << punctuated.size() << endl;
	for(unsigned int q = 0; q < punctuated.size(); q++) {
    //  cout << "-------------------------DOCUMENT--------------------- " << q << endl;
		vector<string> n;
		vector<string> v = punctuated.at(q);
		//cout << v.size() << endl;
	for(unsigned int i = 0; i < v.size(); i++) {
		//cout << "word is " << v.at(i) << " at " << i << endl;
		int excepNum;
		bool exception = false;
		for(unsigned int z = 0; z < noStems.size(); z++) {
			if(noStems.at(z) == v.at(i)) {
				excepNum = z;
				exception = true;
				//cout << "exception: " << v.at(i) << endl;
			}
		}
		string test = "";
		bool allPunct = true;
		if(v.at(i).length() == 0) i++;
		
		//check for plus
		if(v.at(i).at(0) == '+') {
			bool leaveUpper = false;
      if(v.at(i).size() > 1) {
          //cout << "here" << endl;
			for(unsigned int y = 0; y < v.at(i).size(); y++) {
				if(v.at(i).substr(1, v.at(i).length()-1) == v.at(y)) { //unambiguously capitalized elsewhere
					v.at(i) = v.at(i).substr(1, v.at(i).length()-1); //leave it capitalized
					leaveUpper = true;
				}
			}
      }
			if(leaveUpper == false && v.at(i).size() > 1) { //didn't find it elsewhere so we lowercase it
				//cout << "making " << v.at(i) << " lowercase" << endl;
				char a = tolower(v.at(i).at(1));
				v.at(i) = a + v.at(i).substr(2, v.at(i).length()-1);
			}
		}
				
		//still don't stem if it is capital
		for(unsigned int q = 0; q < v.at(i).length(); q++) {
			if(isupper(v.at(i).at(q))) goto noStep;
		}
		
		
		for(unsigned int j = 0; j < v.at(i).size(); j++) {
			if(!ispunct(v.at(i).at(j))) 
				allPunct = false;
		}
		
		if(allPunct == true || exception == true) goto noStep;
		
    //cout << "GOING TO STEM " << endl;
    
		test = st.step1(v.at(i));
		test = st.step2(test);
		test = st.step3(test);
		test = st.step4(test);
		test = st.step5(test);
		test = st.step6(test);
		test = st.step7(test);
		test = st.step8(test);
		
    
		noStep:;
		if(test.length() != 0) {
			//cout << "pushing test as " << test << endl;
			n.push_back(test);
		}
		if(test.length() == 0 && exception == false) {
        //cout << "trying to push at " << i << endl;
			n.push_back(v.at(i));
			//cout << "pushing " << v.at(i) << " size of v is " << v.size() << " at " << i << endl;
		}
		if(exception == true) {
			//cout << "after exception push " << exceptions.at(excepNum) << endl;
			n.push_back(exceptions.at(excepNum));
		}
		//cout << endl;
	}
		//n is being pushed more than once! pull ender.push_back out a loop?
	//cout << "Done Stemming " << endl;
	ender.push_back(n);
	}
	for(unsigned int i = 0; i < ender.size(); i++) {
		//cout << "file " << endl;
		for(unsigned int j = 0; j < ender.at(i).size(); j++) {
			//cout << ender.at(i).at(j) << endl;
		}
		//cout << endl;
	}
	//cout << endl;
	//cout << ender.size() << endl;
	map<double, int> found = print(ender);
	//found contains the doc number and its TFIDF score... loop through and find biggest TFIDF of doc in range
	//iterator loop
	//sort(found.begin(), found.end());
	//cout << "fileNames size " << fileNames.size() << endl;
  //cout << "ABOUT TO CHECK SCORES AND READING LEVELS " << endl;
  //cout << "fileNames length " << fileNames.size() << endl;
	for(map<double, int>::reverse_iterator it=found.rbegin(); it!=found.rend(); ++it) {
      //cout << "new pair " << endl;
		//check reading level and if it matches return fileNames.at(it->second)
    //cout << it->first << " " << it->second << endl;
		//cout << "reading levels at " << fileNames.at(it->second) << endl;
		auto thing = readingLevels.at(fileNames.at(it->second));
		//cout << "thing is " << thing << endl;
		if(thing >= rangeLow && thing <= rangeHigh) {
        //cout << "found it! " << endl;
			cout <<  fileNames.at(it->second) << endl;
			return 0;
		}
		//cout << readingLevels.at(it->second)->first << endl;
		//cout << fileNames.at(it->second) << endl;
	}
	
	cerr << "NOTHING IN RANGE" << endl;
	//cout << fileNames.at(found) << endl;

	return -1; 
}
