//Paul Barstad
//CS253 Assignment 3
//9-15-17


#ifndef DOC_H_INCLUDED
#define DOC_H_INCLUDED

#include <string>
#include <vector>
#include <map>

using namespace std;

vector<string> newPunc(vector<string> inVec);


vector<string> punctuate(vector<string> in);


map<double, int> print(vector<vector<string>> words);
	

#endif
