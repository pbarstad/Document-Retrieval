//Paul Barstad
//CS253 PA4
//10-8-17

#include "stem.h"
#include "lexical.h"
#include <string>
#include <iostream>
#include <fstream>
using namespace std;
Lexical l;

//STEP 1
	string Stem::step1(string s) {
		string temp = "";
	//if string starts with an apostrophe... remove it
		if(s.at(0) == '\'') 
			temp = s.substr(1, s.length()-1);

		if(temp.length() == 0) 
			temp = s;

	//if suffix is 's' remove it
		if(temp.length() > 2) {
			if(temp.substr(temp.length()-3, 3) == "'s'") {
				//cout << "'s' " << temp << endl;
				temp = temp.substr(0, temp.length()-3);
				//cout << temp << endl;
			}
		}
		
	//if suffix is 's remove it
		if(temp.length() > 1) {
			if(temp.substr(temp.length()-2, 2) == "'s")
				temp = temp.substr(0, temp.length()-2);
		}
	//if suffix is ' remove it
		if(temp.length() > 0) {
			if(temp.substr(temp.length()-1, 1) == "'")
				temp = temp.substr(0, temp.length()-1);
		}
	//if none of the step 1 stems occured go on with original string
		
		//if(temp.length() == 0) temp = s;
		//cout << "step1 returns " << temp << endl;
		return temp;
	}

//STEP 2
	string Stem::step2(string s) {
		string temp = "";
	//if suffix sses replace with ss
		//cout << "in step 2" << endl;
		if(s.length() > 3) {
			if(s.substr(s.length()-4, 4) == "sses")
				temp = s.substr(0, s.length()-2);
		}
		//cout << "here" << endl;
	//if suffix is ied or ies
		if(s.length() > 2) {
			//cout << "here" << endl;
			if(s.substr(s.length()-3, 3) == "ied" || s.substr(s.length()-3, 3) == "ies") {
		//if preceder is more than one letter replace with i
				string prec = l.preceder(s);
				if(prec.length() > 1) 
					temp = s.substr(0, s.length()-2);
			//else replace with ie
				else 
					temp = s.substr(0, s.length()-1);
			}
		}
		//cout << "69" << endl;
	//if suffix is us replace with us (do nothing)
		if(s.length() > 1)
			if(s.substr(s.length()-2, 2) == "us" || s.substr(s.length()-2, 2) == "ss")
				return s;

	//if suffix is ss replace with ss (do nothing)
		//NOT PUTTING ANY CODE IN YET BECAUSE IT DOES NOTHING

	//if suffix is s and preceding word part contains a vowel 
	//not immediately before the s, remove the s
		//cout << s.length() << endl;
		if(s.length() > 0) {
			//cout << "79" << endl;
			if(s.substr(s.length()-1, 1) == "s") {
				bool found = false;
				if(s.length() == 1) return s;
				for(unsigned int i = 0; i < s.length()-2; i++) {
					if(l.isVowel(s, i) == true)
						found = true;
				}
				if(found == true)
					temp = s.substr(0, s.length()-1);
			}
		}
		//cout << "89" << endl;
		if(temp.length() == 0) temp = s;
		//cout << "step2 returns " << temp << endl;
		return temp;
	}

//STEP 3
	string Stem::step3(string s) {
		if(s.length() == 0) return s;
		string temp = "";
		
	//if suffix is eed or eedly and suffix occurs in region1 replace with ee
	if(s.length() > 2)
		if(s.substr(s.length()-3, 3) == "eed" && l.Region1(s) == "eed") 
			temp = s.substr(0, s.length()-1);			
		
	//if suffix is... ed, edly, ing, ingly.. and the preceder contains a vowel
		//if(s.substr(s.length()-2,2) == "ed" || s.substr(s.length()-4,4) == "edly" || 
		//s.substr(s.length()-3,3) == "ing" || s.substr(s.length()-5,5) == "ingly") { //out of bounds??
			//remove the suffix
			if(s.length() > 1)
				if(s.substr(s.length()-2,2) == "ed") temp = s.substr(0, s.length()-2);
			if(s.length() > 3)
				if(s.substr(s.length()-4,4) == "edly") temp = s.substr(0, s.length()-4);
			if(s.length() > 2)
				if(s.substr(s.length()-3,3) == "ing") temp = s.substr(0, s.length()-3);
			if(s.length() > 4)
				if(s.substr(s.length()-5,5) == "ingly") temp = s.substr(0, s.length()-5);
			//cout << "here" << endl;
			
			string prec = "";
			if(s.length() > 1)
				prec = l.preceder(s);
			//cout << "prec = " << prec << endl;
		//if preceder ends in at, bl, or iz... add an e
			if(prec.length() > 1) {
				if(prec.substr(prec.length()-2,2) == "at" || prec.substr(prec.length()-2,2) == "bl" || prec.substr(prec.length()-2,2) == "iz") {
				//replace with e.... do you add it to the end of preceder? what if 
					temp = temp + "e"; }
				
		//else if preceder ends in a double, remove the last letter
				if(l.isDouble(prec) == true) 
					temp = temp.substr(0, temp.length()-1);		
					
		//else if the preceder is short, add an e
				 //cout << "hi" << endl;
				if(l.isWordShort(prec)) 
					temp = temp + "e";
				
			}
			//cout << "made it here" << endl;
		if(temp.length() == 0) temp = s;
		//cout << "step3 returns " << temp << endl;
		return temp;
	}

//STEP 4
	string Stem::step4(string s) {
		if(s.length() == 0) return s;
	//if suffix is y and follows a non-vowel that is not the first letter
	//of the preceder, replace the y with an i
	
	//REDO STEP 4 it only cares about the letter immediately before is a nonVowel and is not index zero
	
		string temp = "";
		if(s.substr(s.length()-1,1) == "y") {
			//string prec = preceder(s);
			bool foundNonVowel = false;
			for(int i = s.length()-1; i > 0; i--) {
				if(l.isVowel(s, i) == false)
					foundNonVowel = true;
			}
			if(foundNonVowel == true) 
				temp = s.substr(0, s.length()-1) + "i";
		}
		
		if(temp.length() == 0) temp = s;
		//cout << "step4 returns " << temp << endl;
		return temp;
	}

//STEP 5
	string Stem::step5(string s) {
		if(s.length() == 0) return s;
		string temp = "";
	//if suffix is tional replace with tion
		if(s.length() > 5)
			if(s.substr(s.length()-6, 6) == "tional")
				temp = s.substr(0, s.length()-2);
	//if suffix is enci replace with ence
		if(s.length() > 3) 
			if(s.substr(s.length()-4, 4) == "enci")
				temp = s.substr(0, s.length()-1) + "e";
	//if suffix is anci replace with ance
		if(s.length() > 3) 
			if(s.substr(s.length()-4, 4) == "anci")
				temp = s.substr(0, s.length()-1) + "e";
	//if suffix is abli replace with able
		if(s.length() > 3)
			if(s.substr(s.length()-4, 4) == "abli")
				temp = s.substr(0, s.length()-1) + "e";
	//if suffix is entli replace with ent
		if(s.length() > 4)
			if(s.substr(s.length()-5, 5) == "entli")
				temp = s.substr(0, s.length()-2);
	//if suffix is izer or ization replace with ize
		if(s.length() > 3)
			if(s.substr(s.length()-4, 4) == "izer")
				temp = s.substr(0, s.length()-1);
		if(s.length() > 6)
			if(s.substr(s.length()-7, 7) == "ization")
				temp = s.substr(0, s.length()-7) + "ize";
	//if suffix is ational, ation, or ator replace with ate
		if(s.length() > 6)
			if(s.substr(s.length()-7, 7) == "ational")
				temp = s.substr(0, s.length()-7) + "ate";
		if(s.length() > 4)
			if(s.substr(s.length()-5, 5) == "ation")
				temp = s.substr(0, s.length()-3) + "e";
		if(s.length() > 3)
			if(s.substr(s.length()-4, 4) == "ator")
				temp = s.substr(0, s.length()-2) + "e";
	//if suffix is alism, aliti, or alli replace with al
		if(s.length() > 4)
			if(s.substr(s.length()-5, 5) == "alism" || s.substr(s.length()-5, 5) == "aliti")
				temp = s.substr(0, s.length()-3);
		if(s.length() > 3)
			if(s.substr(s.length()-4, 4) == "alli")
				temp = s.substr(0, s.length()-2);
	//if suffix is fulness replace with ful
		if(s.length() > 6)
			if(s.substr(s.length()-7, 7) == "fulness")
				temp = s.substr(0, s.length()-4);
	//if suffix is ousli or ousness replace with ous
		if(s.length() > 4)
			if(s.substr(s.length()-5, 5) == "ousli")
				temp = s.substr(0, s.length()-2);
		if(s.length() > 6)
			if(s.substr(s.length()-7, 7) == "ousness")
				temp = s.substr(0, s.length()-4);
	//if suffix is iveness or iviti replace with ive
		if(s.length() > 6)
			if(s.substr(s.length()-7, 7) == "iveness")
				temp = s.substr(0, s.length()-4);
		if(s.length() > 4)
			if(s.substr(s.length()-5, 5) == "iviti")
				temp = s.substr(0, s.length()-3) + "e";
	//if suffix is biliti or bli replace with ble
		if(s.length() > 5)
			if(s.substr(s.length()-6, 6) == "biliti")
				temp = s.substr(0, s.length()-5) + "le";
		if(s.length() > 2)
			if(s.substr(s.length()-3, 3) == "bli")
				temp = s.substr(0, s.length()-1) + "e";
	//if suffix is ogi and suffix is preceded by l replace with og
		if(s.length() > 3)
			if(s.substr(s.length()-4, 4) == "logi")
				temp = s.substr(0, s.length()-1);
	//if suffix is fulli replace with ful
		if(s.length() > 4)
			if(s.substr(s.length()-5, 5) == "fulli")
				temp = s.substr(0, s.length()-2);
	//if suffix is lessli replace with less
		if(s.length() > 5)
			if(s.substr(s.length()-6, 6) == "lessli")
				temp = s.substr(0, s.length()-2);
	//if suffix is li and preceder ends in valid li ending remove the li
		if(s.length() > 1)
			if(s.substr(s.length()-2, 2) == "li" && l.isLIending(s))
				temp = s.substr(0, s.length()-2);
		
		if(temp.length() == 0) temp = s;
		//cout << "step5 returns " << temp << endl;
		return temp;
	}

//STEP 6
	string Stem::step6(string s) {
		if(s.length() == 0) return s;
		string temp = "";
		string r1 = l.Region1(s);
	//if suffix is in Region1
		//if suffix is ational replace with ate
			if(s.length() > 6 && r1.length() > 6)
				if(s.substr(s.length()-7, 7) == "ational" && r1.substr(r1.length()-6, 6) == "ational")
					temp = s.substr(0, s.length()-5) + "e";
		//if suffix is tional replace with tion
			if(s.length() > 5 && r1.length() > 5)
				if(s.substr(s.length()-6, 6) == "tional" && r1.substr(r1.length()-6, 6) == "tional")
					temp = s.substr(0, s.length()-2);
		//if suffix is alize replace with al
			if(s.length() > 4 && r1.length() > 4)
				if(s.substr(s.length()-5, 5) == "alize" && r1.substr(r1.length()-5, 5) == "alize")
					temp = s.substr(0, s.length()-3);
		//if suffix is icate, iciti, or ical replace with ic
			if(s.length() > 4 && r1.length() > 4)
				if(s.substr(s.length()-5, 5) == "icate" && r1.substr(r1.length()-5, 5) == "icate")
					temp = s.substr(0, s.length()-3);
			if(s.length() > 4 && r1.length() > 4)
				if(s.substr(s.length()-5, 5) == "iciti" && r1.substr(r1.length()-5, 5) == "iciti")
					temp = s.substr(0, s.length()-3);
			if(s.length() > 3 && r1.length() > 3)
				if(s.substr(s.length()-4 ,4) == "ical" && r1.substr(r1.length()-4, 4) == "ical")
					temp = s.substr(0, s.length()-2);
		//if suffix is ful or ness remove it
			if(s.length() > 2 && r1.length() > 2) 
				if(s.substr(s.length()-3, 3) == "ful" && r1.substr(r1.length()-3, 3) == "ful")
					temp = s.substr(0, s.length()-3);
			if(s.length() > 3 && r1.length() > 3)
				if(s.substr(s.length()-4, 4) == "ness" && r1.substr(r1.length()-4, 4) == "ness")
					temp = s.substr(0, s.length()-4);
	//if suffix is ative and is in region2 remove it
		string r2 = l.Region2(s);
		//cout << "HERE" << endl; //dying at the region2 call
		if(s.length() > 4 && r2.length() > 4)
			if(s.substr(s.length()-5, 5) == "ative" && r2.substr(r2.length()-5, 5) == "ative")
				temp = s.substr(0, s.length()-5);
				
		if(temp.length() == 0) temp = s;
		//cout << "step6 returns " << temp << endl;
		return temp;
	}

//STEP 7
	string Stem::step7(string s) {
		if(s.length() == 0) return s;
		string temp = "";
		string r2 = l.Region2(s);
	//if suffix is in region2
		//suffix is ... al, ance, ence, er, ic, able, ible, ant, ement, 
		//ment, ent, ism, ate, iti, ous, ive, or ize remove it
			if(s.length() > 1 && r2.length() > 1) { //al, er, ic suffixes
				if(s.substr(s.length()-2, 2) == "al" && r2.substr(r2.length()-2, 2) == "al")
					temp = s.substr(0, s.length()-2);
				if(s.substr(s.length()-2, 2) == "er" && r2.substr(r2.length()-2, 2) == "er")
					temp = s.substr(0, s.length()-2);
				if(s.substr(s.length()-2, 2) == "ic" && r2.substr(r2.length()-2, 2) == "ic")
					temp = s.substr(0, s.length()-2);
			}
			if(s.length() > 2 && r2.length() > 2) { //ant, ent, ism, ate, iti, ous, ive, ize suffixes
				if(s.substr(s.length()-3, 3) == "ant" && r2.substr(r2.length()-3, 3) == "ant")
					temp = s.substr(0, s.length()-3);
				if(s.substr(s.length()-3, 3) == "ent" && r2.substr(r2.length()-3, 3) == "ent")
					temp = s.substr(0, s.length()-3);
				if(s.substr(s.length()-3, 3) == "ism" && r2.substr(r2.length()-3, 3) == "ism")
					temp = s.substr(0, s.length()-3);	
				if(s.substr(s.length()-3, 3) == "ate" && r2.substr(r2.length()-3, 3) == "ate")
					temp = s.substr(0, s.length()-3);
				if(s.substr(s.length()-3, 3) == "iti" && r2.substr(r2.length()-3, 3) == "iti")
					temp = s.substr(0, s.length()-3);
				if(s.substr(s.length()-3, 3) == "ous" && r2.substr(r2.length()-3, 3) == "ous")
					temp = s.substr(0, s.length()-3);
				if(s.substr(s.length()-3, 3) == "ive" && r2.substr(r2.length()-3, 3) == "ive")
					temp = s.substr(0, s.length()-3);
				if(s.substr(s.length()-3, 3) == "ize" && r2.substr(r2.length()-3, 3) == "ize")
					temp = s.substr(0, s.length()-3);
			}
			if(s.length() > 4 && r2.length() > 4) //need to catch ement before ment...
				if(s.substr(s.length()-5, 5) == "ement" && r2.substr(r2.length()-5, 5) == "ement")
					temp = s.substr(0, s.length()-5);
					
			if(s.length() > 3 && r2.length() > 3) { //ance, ence, able, ible, ment suffixes
				if(s.substr(s.length()-4, 4) == "ance" && r2.substr(r2.length()-4, 4) == "ance")
					temp = s.substr(0, s.length()-4);
				if(s.substr(s.length()-4, 4) == "ence" && r2.substr(r2.length()-4, 4) == "ence")
					temp = s.substr(0, s.length()-4);
				if(s.substr(s.length()-4, 4) == "able" && r2.substr(r2.length()-4, 4) == "able")
					temp = s.substr(0, s.length()-4);
				if(s.substr(s.length()-4, 4) == "ible" && r2.substr(r2.length()-4, 4) == "ible")
					temp = s.substr(0, s.length()-4);
				if(s.substr(s.length()-4, 4) == "ment" && r2.substr(r2.length()-4, 4) == "ment")
					temp = s.substr(0, s.length()-4);
			}
			
		//if suffix is ion, and the preceder ends with an s or t remove it
			if(s.length() > 3) {
				if(s.substr(s.length()-3, 3) == "ion")
					if(s.substr(s.length()-4, 1) == "s" || s.substr(s.length()-4, 1) == "t")
						temp = s.substr(0, s.length()-3);
			}
			
			if(temp.length() == 0) temp = s;
			//cout << "step7 returns " << temp << endl;
			return temp;
	}

//STEP 8
	string Stem::step8(string s) {
		if(s.length() == 0) return s;
		string r1 = l.Region1(s);
		string r2 = l.Region2(s);
		string prec = l.preceder(s);
		string temp = "";
		
	//if suffix is e
		if(s.length() > 1) {
		//suffix appears in region2 or 
		//(suffix appears in region1 and preceder does not end in short syllable) 
			if(r2.length() > 0)
				if(s.substr(s.length()-1, 1) == "e" && r2.substr(r2.length()-1, 1) == "e")
					temp = s.substr(0, s.length()-1);
			if(r1.length() > 0)
				if(s.substr(s.length()-1, 1) == "e" && r1.substr(r2.length()-1, 1) == "e" && l.isShortSyllable(s) == false)
					temp = s.substr(0,s.length()-1);
			//remove the e
		
	//if suffix is l
		//suffix appears in region2 and preceder ends in l (word ends in ll)
			if(r2.length() > 0)
				if(r2.substr(r2.length()-1, 1) == "l" && s.substr(s.length()-2,1) == "l")
					temp = s.substr(0, s.length()-1);
			//remove one l
		}
		
		if(temp.length() == 0) temp = s;
		//cout << "step8 returns " << temp << endl;
		return temp;
	}
	
	
	
	
	
	
	
	
	
