All input files are in the in/ folder. The following commands were used. Change the file path inside the library file accordingly when you test. Wrong exe name will halve the score. 

***VALID TAR: 5 pts***
***VALID MAKE: 5 pts***

***VALID CASE: 70 pts***

input:
./PA9 in/reference in/library 0 12 

output: (add path accordingly)
history

return value: 
0

***INVALID CASE #1: 5 pts***

input:
./PA9 in/reference in/library 

output:
<any>

return value:
-1


***INVALID CASE #2: 5 pts***

input:
./PA9 in/reference in/library2 1 6.85

output:
<any>

return value:
-1


***INVALID CASE #3: 5 pts***

input:
./PA9 in/reference in/library3 1 6.85

output:
<any>

return value:
-1


***INVALID CASE #4: 5 pts***

input:
./PA9 in/reference in/doesnotexist 1 6.85

output:
<any>

return value:
-1
