//Paul Barstad
//CS253 Assignment 3
//9-15-17

#include "doc.h"
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <fstream>
#include <math.h>
#include <map>
using namespace std;

vector<string> newPunc(vector<string> inVec) {
	vector<string> RET;
	for(unsigned int v = 0; v < inVec.size(); v++) { //loop through all strings
		unsigned int lastAdd = 0;
		//cout << "new word " << inVec.at(v) << endl;
		for(unsigned int i = 0; i < inVec.at(v).length(); i++) { //loop through each character
			//cout << "AT TOP char is " << inVec.at(v).at(i) << endl;
			if(ispunct(inVec.at(v).at(i))) { //if punctuation
				//cout << "PUNCTUATION " << inVec.at(v) << endl;
				//if(i > 0 && i < inVec.at(v).length()) { //prevent out of bounds
				if(inVec.at(v).at(i) == ',' || inVec.at(v).at(i) == '.') {
					//if(inVec.at(v).at(0) == ',') cout << "comma in " << inVec.at(v) << endl;
					if(i == inVec.at(v).length()-1) { goto jump; } // if length of string is zero it will automatically jump to adding it and not out of bound
					if(i == 0 /*&& !isdigit(inVec.at(v).at(i+1))*/) {
					 	//if(inVec.at(v).length() > 0) {
					 		//if(inVec.at(v).at(i+1) != '\'') {
					 			goto jump;
					 		//}
					 	//}
					 }
					if(i > 0 && i < inVec.at(v).length()) {
						if(isdigit(inVec.at(v).at(i-1)) && isdigit(inVec.at(v).at(i+1))) { //if comma between digits
							//cout << "found comma or period between digits" << endl; //do nothing 
						}
						else {
							//cout << "comma or period not between digits in " << inVec.at(v) << endl;
							goto jump;	
						}
					}
				}
				//else if(i == 0 && inVec.at(v).at(i) == '.' /*&& inVec.at(v).length() > 1 && isdigit(inVec.at(v).at(1))*/) { //if period is first character and digit follows
				/*	cout << "found period at beggining of string" << endl; //do nothing
				} */
				else if(inVec.at(v).at(i) == '\'') { } //do nothing for apostrophes
				else {
					jump:;
					//cout << "punctuation should break" << endl;
					if(lastAdd != i ) {  RET.push_back(inVec.at(v).substr(lastAdd, i-lastAdd)); lastAdd = i;}
					while(i < inVec.at(v).length() && ispunct(inVec.at(v).at(i))) {
						i++; //go forward til not punctuation or end of string
						//cout << "moving up" << endl;
					}
					//cout << "pushing " << inVec.at(v).substr(lastAdd, i-lastAdd) << " FIRST TIME " << endl;
					RET.push_back(inVec.at(v).substr(lastAdd, i-lastAdd));
					lastAdd = i;
				}
			//check if lastAdd is up to length (won't be if there is no punctuation)
			}	
		}
		if(lastAdd != inVec.at(v).length()) { 
        RET.push_back(inVec.at(v).substr(lastAdd, inVec.at(v).length()-lastAdd)); 
        //cout << "pushing " << inVec.at(v).substr(lastAdd, inVec.at(v).length()-lastAdd) << endl;
    }
	}
	return RET;
}

vector<string> punctuate(vector<string> in) {
	//sort(in.begin(), in.end());
	vector<string> x;
	
	for(unsigned int i = 0; i < in.size(); i++) { //loop through all strings split by whitespace
		unsigned int lastAdd = 0;
		for(unsigned int j = 0; j < in.at(i).length(); j++) { //loop through chars of string if has punctuation
			//cout << j << endl;
			//lastAdd will be one past what the end of the string was so you can grab from right there.
			//cout << "string is " << in.at(i) << " with length " << in.at(i).length() << " at position " << j << endl;
			//cout << "current character is " << in.at(i).at(j) << endl;
			
			if(in.at(i).length()-1 == j && (in.at(i).at(j) == '.' || in.at(i).at(j) == ',')) {
				//cout << "period at end " << in.at(i) << endl;
				//cout << lastAdd << " " << j << endl;
				//cout << "pushing " << in.at(i).substr(lastAdd, j-lastAdd) << endl;
				if(in.at(i).length() == 1) {
					if(in.at(i).at(j) == '.')
						x.push_back(".");
					if(in.at(i).at(j) == ',')
						x.push_back(",");
				}
				if(in.at(i).length() > 1)
					x.push_back(in.at(i).substr(lastAdd, j-lastAdd)); //add up until where punctuation was found
				lastAdd = j;
				goto commaperiod_done;
			}
			
			
			//OLD CODE START
			if((in.at(i).at(j) == ',' || in.at(i).at(j) == '.') && j != in.at(i).length()-1) { //if comma or period
				//cout << "found comma or period" << endl;
				//if(in.at(i) == "2.0")
				
					//cout << isdigit(in.at(i).at(j+1)) << endl;
				if(j == 0 || j == in.at(i).length()-1 || ((isdigit(in.at(i).at(j-1)) && isdigit(in.at(i).at(j+1))) == false)) { //at beginning or not between digits// foo -- not at EOL
					//if(j == 0) cout << "Found " << in.at(i) << endl;
					//comma and period should break the string
					if(lastAdd != j && j != 0) {
						//cout << "pushing " << in.at(i).substr(lastAdd, j-lastAdd) << endl;
						x.push_back(in.at(i).substr(lastAdd, j-lastAdd)); //add up until where punctuation was found
						lastAdd = j;
					}
					while(ispunct(in.at(i).at(j)) && j < in.at(i).length()-1) { //go until no more punctuation
						j++;
						//cout << "going for more punctuation" << endl;
						//cout << j << endl;
						if(j == in.at(i).length()-1 ) goto commaperiod_done; //break; //at end of string and will crash in while loop 
					} 
					if((j == 1 && isdigit(in.at(i).at(1)) && in.at(i).at(0) == '.')) goto commaperiod_done;
					//cout << "pushing " << in.at(i).substr(lastAdd, j-lastAdd) << endl;
					if(j > 0 && (in.at(i).at(j-1) == '.' || in.at(i).at(j-1) == ',')) {
						x.push_back(in.at(i).substr(lastAdd, j-lastAdd)); //add all continuous punctuation to x
					//cout << "j= " << j << " adding " << in.at(i).substr(lastAdd, j-lastAdd) << endl;
						lastAdd = j;
						//cout << "here lastAdd updated" << endl;
					}
					//cout << "BREAKING" << endl;
				goto commaperiod_done;
			//		break; //THIS CHANGES THE OUTPUT FROM THE BREAK A COUPLE LINES DOWN BUT CAN'T FIND THE RIGHT WAY TO ACCOUNT FOR LEGAL PERIODS OR COMMAS........
				}
				//cout << "going back to top" << endl;
				//break; //back to top of character loop
				
			} //end of if comma or period
			
			/*if(in.at(i).length() > 0) {
				if(j == in.at(i).length()-1 && (in.at(i).at(j-1) == '.' || in.at(i).at(j-1) == ',')) {
					//found comma or period at the end
					cout << "here" << endl;
					//cout << "end period/comma " << in.at(i).substr(lastAdd, j-lastAdd) << endl;
					x.push_back(in.at(i).substr(lastAdd, j-lastAdd));
				}
			}*/
			
			
			//OLD CODE STOP
			if(in.at(i).at(j) == '\'') {
				if ( j != 0) {
					if (!ispunct(in.at(i).at(j-1))) { goto commaperiod_done; }
				}
				if (j != in.at(i).length()-1) {
					if (!ispunct(in.at(i).at(j+1))) { goto commaperiod_done; }
				}
				if (( j == 0) || (j == in.at(i).length()-1)) { goto commaperiod_done; }					
			} //apostrophe does not break strings
			
			if(ispunct(in.at(i).at(j)) && ((in.at(i).at(j) != ',') && (in.at(i).at(j) != '.'))) { //if special punctuation
				//cout << "at special punctuation" << endl;
				if(lastAdd != j && j != 0) { //needs to catch up
					x.push_back(in.at(i).substr(lastAdd, j-lastAdd)); //add up until where punctuation was found
					lastAdd = j;
				}
				while(ispunct(in.at(i).at(j)) && (in.at(i).at(j) != '\'') && j < in.at(i).length()) { //go until no more punctuation
					j++;
					if(j == in.at(i).length()) goto killwhile; // break; //at end of string and will crash in while loop 
				} 
				killwhile:;
				//cout << "pushing " << in.at(i).substr(lastAdd, j-lastAdd) << endl;
				x.push_back(in.at(i).substr(lastAdd, j-lastAdd)); //add all continuous punctuation to x
				lastAdd = j;
				
				//break; //back to top of character loop
			} //end of spcial punctuation 
			
			
			//if j is at end and lastAdd != j
			//cout << "here" << endl;
			//cout << "didn't break, j is " << in.at(i).at(j) << endl;
			//cout << j << endl;
			commaperiod_done:;
			//if (j == 0) cout << "at commaperiod_done" << endl;
			if(j == in.at(i).length()-1) {
				//cout << "in loop " << in.at(i) << endl;
				x.push_back(in.at(i).substr(lastAdd, in.at(i).length()-lastAdd)); //add remaining string
				//cout << "pushing " << in.at(i).substr(lastAdd, in.at(i).length()-lastAdd) << endl;
				lastAdd = j;
				//do i need to break? or no because this assumes you are at end of string anyway?
			}
		} //end loop through each string
		//cout << "done with " << in.at(i) << endl;
	} //end loop of words
	//cout << endl;
	return x;
} //end punctuate

	vector<map<string, int>> BigVec;
	//vector<vector<int>> Bcounts;
	//use map instead???
	

map<double, int>  print(vector<vector<string>> ender) {
	//cout << "in print" << endl;
	for(unsigned int z = 0; z < ender.size(); z++) {
		//cout << "each document" << endl;
		vector<string> words = ender.at(z);
		//make vector sorted alphabetically
		sort(words.begin(), words.end());
	
		//the two vectors that will become output
		//vector<string> newvec;	
		//vector<int> counts;
		map<string, int> wordCounts;
		
		
		for(unsigned int i = 0; i < words.size(); i++) { //go through all input
		
			//cout << "word " << words.at(i) << endl;
			if(i == 0) { //if no output
				//newvec.push_back(words.at(i)); //add new word
				//counts.push_back(1); //make count 1
				wordCounts.insert(pair<string,int>(words.at(i),1));
			}
			else if(wordCounts.count(words.at(i)) > 0) {
				wordCounts[words.at(i)]++;
				//counts.at(counts.size()-1)++; 
				//if word already added increment count
			}
			else {
				//newvec.push_back(words.at(i)); //otherwise add new word
				//counts.push_back(1); //make count one
				wordCounts.insert(pair<string,int>(words.at(i),1));
			}
		}
		BigVec.push_back(wordCounts);
		//cout << Bnewvec.size() << " " << Bnewvec.at(0).at(1) << endl;
		
		//cout << Bcounts.size() << endl;

		//print it
		//for(unsigned int j = 0; j < newvec.size(); j++) {
			//cout << newvec.at(j) << " " << counts.at(j) << endl;
			//cout << "printing" << endl;
		//}
	}
	//cout << "done with counts" << endl;
	//calculate TFIDF
	//vector<vector<double>> TFIDF;
	
	for(unsigned int i = 0; i < BigVec.size(); i++) {
		//cout << "DOCUMENT " << i << endl;
		for (map<string,int>::iterator it=BigVec.at(i).begin(); it!=BigVec.at(i).end(); ++it) {
			//cout << it->first << " " << it->second << endl;
		}
	} 
	
	map<string, double> IDF;
	
	for(unsigned int i = 0; i < BigVec.size(); i++) {
		//cout << "new document" << endl;
		for (map<string,int>::iterator it=BigVec.at(i).begin(); it!=BigVec.at(i).end(); ++it) { //std::cout << it->first << " => " << it->second << '\n';
			//cout << "new word" << endl;
    	bool allPunct = true;
    	double idf = 0.0;
    	//if allPunct check do nothing
    	for(unsigned int a = 0; a < (it->first).length(); a++) {
    		if(!ispunct((it->first).at(a))) allPunct = false;
    	}
    	if(IDF.count(it->first) == 0) { //if idf does not already have word
    		//cout << it->first << "not in IDF yet" << endl;
    		//if allPunct check do nothing
				if(allPunct == false) { //else calculate idf
					double n = 1; //number of documents the word appears in -- already found in current document
					for(unsigned int b = i+1; b < BigVec.size(); b++) {
						//cout << "looping through remaining documents" << endl;
						if(BigVec.at(b).count((it->first)) > 0) {//found that word
							//cout << "found " << it->first << endl;
							n++;
						}
					}
					idf = log10(BigVec.size()/n);
					//cout << it->first << endl;
					//cout << idf << " = " << "log10(" << BigVec.size() << "/" << n << ")" << endl;
					//IDF.insert(pair<string, double>((it->first), idf));
    		}
    		//else { cout << "already in map" << endl; }
    		
    		//cout << "inserting " << it->first << " " << idf << endl;
    		IDF.insert(pair<string, double>((it->first), idf));
    	}
   	}
	} //IDF scores now stored for all values
	//cout << "DONE with IDF" << endl;
	
	//int BIGGEST = 0;
	//double largest;
  map<double, int> mapOut;
	for(unsigned int i = 0; i < BigVec.size()-1; i++) {
		//cout << "calculating tfidf" << endl;
		
		//for(unsigned int b = 0; b < BigVec.size(); b++) {
			double TFIDF = 0.0;
			double tfidf = 0.0;
			for(map<string,int>::iterator it=BigVec.at(i+1).begin(); it!=BigVec.at(i+1).end(); ++it) {
				string word = it->first;
				//cout << word << endl;
				//for(unsigned int b = i+1; b < BigVec.size(); b++) {
				if(BigVec.at(0).count((it->first)) > 0) { //found in both documents
					//cout << "found " << word << " in both documents " << i << " and " << b << endl;
					//cout << "tfidf = " << it->second << " * " << IDF.at(word) << " * " << BigVec.at(b).at(word) << " * " << IDF.at(word) << endl;
					tfidf = (it->second * IDF.at(word)) * (BigVec.at(0).at(word) * IDF.at(word));
					//cout << tfidf << endl;
				}
				if(tfidf != 0.0)
					//cout << TFIDF << " + " << tfidf << " for " << word << endl;
				TFIDF += tfidf;
				tfidf=0.0;
			}
			
			mapOut.insert(pair<double, int>(TFIDF, i+1));
			
			//cout << TFIDF << " ";
		//}
		//cout << TFIDF << " ";
		/*if(i == 0) { 
			BIGGEST = 1;
			largest = TFIDF;
		}
		if(largest < TFIDF) {
			largest = TFIDF;
			BIGGEST = i + 1;
		} */
		//cout << endl;
	}
	//cout << log10(1) << endl;
	//cout << endl;
	
		return mapOut;
	
	
		/*vector<double> tfidf;
		if(TFIDF.size() == 0) {
			//cout << "once" << endl;
			for(unsigned int j = 0; j < Bnewvec.size(); j++) {
				//cout << "here" << endl;
				unsigned int n = 1; //found one at the beginning
				for(unsigned int k = 0; k < Bnewvec.at(j).size(); k++) {
					string temp = Bnewvec.at(j).at(k);
					int freq = Bcounts.at(j).at(k);
					if(temp == Bnewvec.at(j).at(k) && n < j) {
						n += Bcounts.at(j).at(k);
					}
					//cout << n << endl;
					double idf = log10(Bnewvec.size()/n);
					//cout << idf << endl;
					//cout << "n " << n << endl;
					//cout << "idf " << idf << endl; 
					//cout << temp << " " << (freq * idf) << endl; 
					//cout << "pushing " << (freq * idf) << endl;
					tfidf.push_back(freq * idf);
				}
				//cout << endl;
				TFIDF.push_back(tfidf);
			}
		}
	}
	//cout << TFIDF.size() << endl;
	double sum = 0;
	for(unsigned int a = 0; a < Bnewvec.size(); a++) { //loop through number of files
		for(unsigned int x = 0; x < Bnewvec.size(); x++) {
			for(unsigned int b = 0; b < Bnewvec.at(a).size(); b++) { //loop through each file
				string temp = Bnewvec.at(a).at(b);
				for(unsigned int y = 0; y < Bnewvec.at(x).size(); y++) {
					if(temp == Bnewvec.at(x).at(y))
						sum += TFIDF.at(a).at(b) + TFIDF.at(x).at(y);
				}
			}	
			cout << sum << " ";
			sum = 0;
		}
		cout << endl; */
		/*
		if(a < Bnewvec.size()-1) {
			for(unsigned int b = 0; b < Bnewvec.at(a).size(); b++) { //loop through each file
				string temp = Bnewvec.at(a).at(b);
				for(unsigned int c = 0; c < Bnewvec.at(a).size(); c++) { //loop through each file again
					if(temp == Bnewvec.at(a).at(c)) {
						sum += TFIDF.at(a).at(b) + TFIDF.at(a).at(c);
					}
				}
			}*/
			
		
			//cout << endl;
	//}
	//cout << TFIDF.at(0).at(0) << endl;
	//cout << TFIDF.at(1).at(0) << endl;
}
	




